import React from 'react'
import Header from '../Components/Header'

export default function Order() {
    return (
        <div>
            <Header title='Order' />
        </div>
    )
}

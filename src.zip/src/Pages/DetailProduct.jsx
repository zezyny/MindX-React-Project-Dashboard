import React, { useContext, useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { FirebaseContext } from '../Context/FirebaseProvider'
import { onSnapshot, query } from 'firebase/firestore'
import Header from '../Components/Header'
export default function DetailProduct() {
    let param = useParams()
    let [product, setProduct] = useState([])
    const { messCollect } = useContext(FirebaseContext)
    useEffect(() => {
        const q = query(messCollect);
        const unsubscribe = onSnapshot(q, (querySnapshot) => {
            const temp = [];
            querySnapshot.forEach((doc) => {
                temp.push({ ...doc.data(), id: doc.id });
            });
            setProduct(temp)
        });
    }, [])
    let { id } = param
    console.log(product);
    let viewingProduct = product.find((item) => {
        {
            return item.id == id
        }
    })
    console.log(viewingProduct);
    let { productName } = viewingProduct
    // breadcrumb=====================
    const breadcrumb = [
        {
            title: <Link to={'/'}>Dashboard</Link>
        },
        {
            title: <Link to={'/products'}>Products</Link>
        },
        {
            title: <span>{productName}</span>
        }
    ]
    return (
        <div>
            <Header title={productName} breadcrumb={breadcrumb} />
            <div className="body-content">

            </div>
        </div>
    )
}

import React, { useContext, useEffect, useState } from 'react'
import Header from '../Components/Header'
import { FirebaseContext } from '../Context/FirebaseProvider'
import { addDoc, onSnapshot, query } from 'firebase/firestore'
import { Link } from 'react-router-dom'
import { Button, ColorPicker, Form, Input, InputNumber, Tag } from 'antd';
import TextArea from 'antd/es/input/TextArea'
export default function NewProduct() {
    const [title, setTitle] = useState('')
    const [desc, setDesc] = useState('')
    const [price, setPrice] = useState('')
    const [discount, setDiscount] = useState('')
    const [quantity, setQuantity] = useState('')
    const [color1, setColor1] = useState('')
    const [color2, setColor2] = useState('')
    const [color3, setColor3] = useState('')
    const [varName1, setVarName1] = useState('')
    const [varName2, setVarName2] = useState('')
    const [varName3, setVarName3] = useState('')
    const [imgLink1, setImgLink1] = useState('')
    const [imgLink2, setImgLink2] = useState('')
    const [imgLink3, setImgLink3] = useState('')
    let [product, setProduct] = useState([])
    const { messCollect } = useContext(FirebaseContext)
    useEffect(() => {
        const q = query(messCollect);
        const unsubscribe = onSnapshot(q, (querySnapshot) => {
            const temp = [];
            querySnapshot.forEach((doc) => {
                temp.push({ ...doc.data(), id: doc.id });
            });
            setProduct(temp)
        });
    }, [])
    // breadcrumb=====================
    const breadcrumb = [
        {
            title: <Link to={'/'}>Dashboard</Link>
        },
        {
            title: <Link to={'/products'}>Products</Link>
        },
        {
            title: 'New products'
        }
    ]
    //category===========================
    const categoryList = ['Bedroom', 'Decor', 'Office', 'Living Room',]
    const [selectedTags, setSelectedTags] = useState([]);
    const handleChangeTag = (tag, checked) => {
        const nextSelectedTags = checked
            ? [...selectedTags, tag]
            : selectedTags.filter((t) => t !== tag);
        console.log('Category ', nextSelectedTags);
        setSelectedTags(nextSelectedTags);
    };
    // handle change input ======================
    const handleChangeTitle = (e) => {
        setTitle(e.target.value)
    }
    const handleChangeDesc = (e) => {
        setDesc(e.target.value)
    }
    const handleChangePrice = (value) => {
        setPrice(value)
    }
    const handleChangeDiscount = (value) => {
        setDiscount(value)
    }
    const handleChangeQuantity = (value) => {
        setQuantity(value)
    }

    const handleChangeVarName1 = (e) => {
        setVarName1(e.target.value)
    }
    const handleChangeImg1 = (e) => {
        setImgLink1(e.target.value)
    }

    const handleChangeVarName2 = (e) => {
        setVarName2(e.target.value)
    }
    const handleChangeImg2 = (e) => {
        setImgLink2(e.target.value)
    }

    const handleChangeVarName3 = (e) => {
        setVarName3(e.target.value)
    }
    const handleChangeImg3 = (e) => {
        setImgLink3(e.target.value)
    }
    // handle add product========================
    const addNewProduct = async () => {
        await addDoc(messCollect, {
            productName: `${title}`,
            description: `${desc}`,
            categories: `${[selectedTags]}`,
            price: `${price}`,
            discount: `${discount}`,
            stock: `${quantity}`,
            img: [
                `${imgLink1}`,
                `${imgLink2}`,
                `${imgLink3}`
            ],
            productColor: [
                {
                    colorCode: `${color1}`,
                    nameColor: `${varName1}`
                },
                {
                    colorCode: `${color2}`,
                    nameColor: `${varName2}`
                },
                {
                    colorCode: `${color3}`,
                    nameColor: `${varName3}`
                },
            ]
        })
    }

    return (
        <div>
            <Header title='New products' breadcrumb={breadcrumb} />
            <div className="body-content">
                <Form
                    layout='horizontal'
                    labelCol={{ span: '3' }}
                    wrapperCol={{ span: '18' }}
                >
                    <Form.Item label='Product name' rules={[
                        {
                            required: true,
                            message: 'Please input product name!'
                        }
                    ]}>
                        <Input value={title} onChange={handleChangeTitle} />
                    </Form.Item>
                    <Form.Item label='Description'>
                        <TextArea value={desc} onChange={handleChangeDesc} rows={10} />
                    </Form.Item>
                    <Form.Item label='Price' >
                        <InputNumber
                            type='number'
                            onChange={handleChangePrice}
                            style={{ width: '30%', marginRight: '10px' }}
                            placeholder='Price'
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input product name!'
                                }
                            ]} />
                        <InputNumber
                            type='number'
                            onChange={handleChangeDiscount}
                            style={{ width: '30%', marginRight: '10px' }}
                            placeholder='Discount' />
                    </Form.Item>
                    <Form.Item label='Quantity'>
                        <InputNumber
                            type='number'
                            onChange={handleChangeQuantity}
                            style={{ width: '30%', marginRight: '10px' }}
                            placeholder='Quantity'
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input product name!'
                                }
                            ]} />
                    </Form.Item>
                    <Form.Item label='Category'>
                        {categoryList.map((tag) => (
                            <Tag.CheckableTag
                                key={tag}
                                checked={selectedTags.includes(tag)}
                                onChange={(checked) => handleChangeTag(tag, checked)}
                            >
                                {tag}
                            </Tag.CheckableTag>
                        ))}
                    </Form.Item>
                    <Form.Item label='Variation'>
                        <div style={{ display: 'flex', gap: '30px', justifyContent: 'space-between' }}>
                            <Form.Item getValueFromEvent={(color) => { setColor1("#" + color.toHex()) }}>
                                <div style={{ display: 'flex', gap: '5px' }}>
                                    <ColorPicker defaultValue='#59CABF' />
                                    <Input placeholder='Name Variation 1' value={varName1} onChange={handleChangeVarName1} />
                                </div>
                                <Input placeholder='Image Link' style={{ margin: '5px 0' }} value={imgLink1} onChange={handleChangeImg1} />
                            </Form.Item>
                            <Form.Item getValueFromEvent={(color) => { setColor2("#" + color.toHex()) }}>
                                <div style={{ display: 'flex', gap: '5px' }}>
                                    <ColorPicker defaultValue='#59CABF' />
                                    <Input placeholder='Name Variation 2' value={varName2} onChange={handleChangeVarName2} />
                                </div>
                                <Input placeholder='Image Link' style={{ margin: '5px 0' }} value={imgLink2} onChange={handleChangeImg2} />
                            </Form.Item>
                            <Form.Item getValueFromEvent={(color) => { setColor3("#" + color.toHex()) }}>
                                <div style={{ display: 'flex', gap: '5px' }}>
                                    <ColorPicker defaultValue='#59CABF' />
                                    <Input placeholder='Name Variation 3' value={varName3} onChange={handleChangeVarName3} />
                                </div>
                                <Input placeholder='Image Link' style={{ margin: '5px 0' }} value={imgLink3} onChange={handleChangeImg3} />
                            </Form.Item>
                        </div>
                    </Form.Item>
                    <Form.Item
                        wrapperCol={{
                            offset: 3
                        }}>
                        <Button type="primary" htmlType="submit" onClick={addNewProduct}>
                            Submit
                        </Button>
                    </Form.Item>
                </Form>
            </div>
        </div>
    )
}

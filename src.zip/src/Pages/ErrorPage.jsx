import React from 'react'

export default function ErrorPage() {
    return (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
            <img src="https://www.artzstudio.com/content/images/wordpress/2020/05/404-error-not-found-page-lost.png" alt="404" style={{ width: '40%' }} />
        </div>
    )
}

import React from 'react'
import Header from '../Components/Header'

export default function Customer() {
    return (
        <div>
            <Header title='Customers'></Header>
        </div>
    )
}

import React from 'react'
import Header from '../Components/Header'

export default function Dashboard() {
    return (
        <div>
            <Header title='Dashboard' />
        </div>
    )
}
